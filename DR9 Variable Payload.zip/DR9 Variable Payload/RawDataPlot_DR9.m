close all
clear all
SamplingRate = 2.048e-5;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Load data
Data_DR9=readmatrix("DR9_Pt_14dbm_variable_payload");
Time = (1:1:length(Data_DR9)).*SamplingRate*1e3;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plot Data
plot(Time,Data_DR9)
ylabel('Current Consumption [mA]','Interpreter','Latex','FontSize', 14)
xlabel('Time [ms]','Interpreter','Latex','FontSize', 14)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%