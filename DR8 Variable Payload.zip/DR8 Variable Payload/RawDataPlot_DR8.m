close all
clear all
SamplingRate = 2.048e-5;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Load data
Data_DR8=readmatrix("DR8_Pt_14dbm_variable_payload.csv");
Time = (1:1:length(Data_DR8)).*SamplingRate*1e3;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%% Plot Data
plot(Time,Data_DR8)
ylabel('Current Consumption [mA]','Interpreter','Latex','FontSize', 14)
xlabel('Time [ms]','Interpreter','Latex','FontSize', 14)
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%